# 예측·발주안 평가 엔진 단독 실행 묶음 (2026-10-31)

이 폴더만 있으면 데이터 폴더를 가리켜 예측과 발주안 평가를 돌릴 수 있다. 데이터(CSV 17개)는 포함하지 않았다. 공개 저장소에 올리지 말 것.

## 준비

- Python 3.10 이상, `pip install -r requirements.txt` (pandas, numpy)
- 제공 데이터 폴더 경로 확인. 예: `C:/.../크라이치즈버거_AX해커톤_주제1_데이터/data` (zip 그대로도 됨)
- Windows 콘솔에서 한글이 깨지면 `set PYTHONUTF8=1` (PowerShell: `$env:PYTHONUTF8=1`) 후 실행

## 실행 (압축을 푼 폴더에서)

```bash
# A. 엔진 전체: 예측 → 소요량 → σ → 로트 FEFO 재고 전개 → 발주 추천 → 알림
python run_forecast.py --data "<CSV 폴더 또는 zip>" --out forecast_out
python run_forecast.py --data "<CSV 폴더>" --forecast-only            # 예측·소요량·σ 까지만
python run_forecast.py --data "<CSV 폴더>" --asof 2026-09-23 --service-level 0.99 --demand-pct 10

# B. 발주안 평가 (계획 (2)): 발주안을 넣으면 품절·폐기·비용을 기대 경로 + 과거 잔차 시나리오 분포로 예측
python run_evaluate.py --data "<CSV 폴더>" --out eval_out                 # 기본: '발주 없음' vs '엔진 추천안'
python run_evaluate.py --data "<CSV 폴더>" --scale 1.3 --scale 0.7        # 추천안 × 배율 안 추가
python run_evaluate.py --data "<CSV 폴더>" --plan my_plan.csv             # 내 발주안 (열: store_id, ingredient_id, order_qty[, order_date, arrival_date, order_type])

# C. 예측 방법 비교 백테스트 / 예측표 (엔진과 독립)
python -X utf8 analysis/backtest_forecast.py "<CSV 폴더>"
python -X utf8 analysis/forecast_table.py "<CSV 폴더>" forecast_table_out
```

## 예측식 (실데이터 백테스트로 선택, 엔진에 반영됨)

```
메뉴 예측 = 같은 요일 최근 4회 평균(공휴일·미취급·첫 판매 전 제외, 최대 6주) × 공휴일 계수(매장별 평일/주말) × 프로모션(대상 메뉴) × 취급 × 시나리오
식자재 소요량 = Σ 메뉴 예측 × BOM (세트는 세트 BOM)
안전재고 = z(서비스 레벨) × σ_L,  σ_L = 같은 식을 과거에 매일 적용한 식자재 단위 잔차의 L일 합계 RMSE (급변 품목 ×1.6)
```
추세 항은 백테스트에서 오차를 키워 기본 꺼짐 (`EngineParams(apply_trend=True)`로 켤 수 있음).
성적 (3~9월 매일 기준일, 1~7일 앞): 메뉴 WAPE 27.7%, 식자재 1~3일 합계 10.8% (7일 이동평균 13.3%).

## 발주안 평가 방식 (run_evaluate / src/engine/evaluate.py)

- 평가 창 = 내일부터 그 다음 발주분 도착 전날까지 (공급사 달력, 발주 추천과 같은 구간). 창 밖 품절은 다음 발주 결정의 몫.
- 폐기는 기간(14일) 전체. 이후 추가 발주는 없다고 봄.
- 변동성 = 과거에 같은 예측식을 적용한 식자재 단위 실제/예측 비율을 기간 길이 블록으로 잘라 시나리오(실데이터 232개)로 사용. 매장·식자재 동시성 보존.
- 품절 손실 매출 = Σ 메뉴가격 × 예측 판매 × (그 메뉴 재료 중 가장 모자란 재료의 부족 비율). 폐기 비용 = 폐기 수량 × 기준일 단가. 발주 금액은 지출로 별도.
- 산출: `compare.csv`(발주안 비교), `<발주안>/lines.csv`(매장×식자재: 기대 경로 + 평균·p90·품절 확률), `daily.csv`(일별 전개), `scenarios.csv`(시나리오별 손실), `totals.json`, `assumptions.txt`

## 산출물 (`forecast_out/`)

| 파일 | 내용 |
|---|---|
| forecast_menu_daily.csv | 매장×메뉴×날짜 예측 (base_qty, holiday/promo 계수, is_available, forecast_qty) |
| forecast_basis.csv | 예측 근거: 같은 요일 실제값 목록, 계수별 근거 문장, 메뉴 σ |
| requirement_ingredient_daily.csv | 매장×식자재×날짜 소요량 (use_unit) |
| sigma_ingredient.csv | 식자재 σ (sigma_by_L: 커버일수 1~7일 합계 RMSE, shift_flag) |
| projection_summary.csv, projection_daily.csv, expiring_lots.csv | 재고 전개: 품절 예상일, 커버 일수, 예상 폐기, 임박 로트 |
| orders_lines.csv, orders_pos.csv | 발주 추천 라인(explain JSON 포함)과 발주서 합계·최소금액 상태 |
| alerts.csv | 품절위험·사용기한임박·과잉 |
| assumptions.txt, briefing.txt, run_info.json | 적용 가정, 규칙 기반 브리핑, 실행 정보 |

## 파일 구성

```
run_forecast.py, run_evaluate.py        실행 진입점
src/__init__.py, schema.py, parsers.py, loader.py, prep.py   데이터 로드·전처리 (엔진 의존성)
src/engine/  params, forecast, requirement(σ·백테스트 배열), projection, order, alerts, alternatives, evaluate, run
analysis/forecast_table.py, backtest_forecast.py              예측표·방법 비교 (독립 스크립트)
requirements.txt
```
