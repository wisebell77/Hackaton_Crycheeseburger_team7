"""수요 예측표 (읽기 전용). 사용: python -I -X utf8 forecast_table.py <csv 폴더> <출력 폴더>

방법 (백테스트로 선택):
  메뉴 예측 = 같은 요일 최근 4회 평균(공휴일 제외, 최대 6주 거슬러 올라감) × 공휴일 계수(매장별, 요일 보정) × 취급 여부
  추세 항 없음. 식자재 소요량 = 메뉴 예측 × BOM (세트는 세트 BOM).
  변동성 σ = 같은 방법의 백테스트(3/1~9/30) 잔차를 매장×식자재×커버일수(1~7일 합계) 단위로 RMSE.
  급변 플래그 = 식자재 소요량 최근 2주 / 8주 비율이 [0.77, 1.3] 밖이면 σ × 1.6.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

pd.set_option("display.width", 240); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 300)
D, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
rd = lambda n: pd.read_csv(next(D.glob(f"{n}_*.csv")), encoding="utf-8-sig")
stores_df = rd("01"); menus = rd("02"); ing = rd("03"); bom = rd("04"); avail = rd("15"); cal = rd("07")
sales = rd("09"); sales["date"] = pd.to_datetime(sales["date"]); cal["date"] = pd.to_datetime(cal["date"])
inv = rd("10"); inv["date"] = pd.to_datetime(inv["date"])
po = rd("11"); rc = rd("12")

ASOF = pd.Timestamp("2026-09-30"); HORIZON = 14
FUTURE_HOL = {pd.Timestamp("2026-10-03"): "개천절", pd.Timestamp("2026-10-05"): "대체공휴일(개천절)", pd.Timestamp("2026-10-09"): "한글날"}
Z95 = 1.645; SHIFT_MULT = 1.6
stores = ["S01", "S02", "S03"]; menu_ids = list(menus.menu_id); ing_ids = list(ing.ingredient_id)
WD = "월화수목금토일"

# ---- 날짜축: 과거 273일 + 미래 14일
hist_dates = pd.DatetimeIndex(cal.date); T = len(hist_dates)
dates = hist_dates.append(pd.date_range(ASOF + pd.Timedelta(days=1), periods=HORIZON))
N = len(dates); didx = {d: i for i, d in enumerate(dates)}
is_hol = np.zeros(N, dtype=bool); is_hol[:T] = cal.is_holiday.values.astype(bool)
hol_name = dict(zip(cal.date, cal.holiday_name.fillna("")))
for d, nm in FUTURE_HOL.items():
    is_hol[didx[d]] = True; hol_name[d] = nm + " (가정: 달력에 없음)"
wd = np.array([d.weekday() for d in dates])

# ---- 수요 행렬 X[s, m, t] (과거만), 취급 마스크 A[s, m, t] (미래는 9/30 상태 이어감)
X = np.full((3, len(menu_ids), N), np.nan); X[:, :, :T] = 0.0
for (s, m, d), v in sales.groupby(["store_id", "menu_id", "date"]).demand_qty.sum().items():
    X[stores.index(s), menu_ids.index(m), didx[d]] = v
A = np.zeros((3, len(menu_ids), N), dtype=bool)
for r in avail.itertuples():
    if r.status == "취급" and isinstance(r.start_date, str):
        si, mi = stores.index(r.store_id), menu_ids.index(r.menu_id)
        A[si, mi, didx[pd.Timestamp(r.start_date)]:didx[pd.Timestamp(r.end_date)] + 1] = True
first_sale = {}
for si in range(3):
    for mi in range(len(menu_ids)):
        nz = np.where(np.nan_to_num(X[si, mi, :T]) > 0)[0]
        if len(nz):
            A[si, mi, :nz[0]] = False; first_sale[(si, mi)] = dates[nz[0]]
        else:
            A[si, mi, :] = False
        A[si, mi, T:] = A[si, mi, T - 1]  # 미래 = 기준일 상태 이어감 (가정)

# ---- 공휴일 계수 (매장별, 요일 보정): 공휴일 실제 매장 수요 / 같은 요일 ±4주 비공휴일 평균
tot = np.nan_to_num(X[:, :, :T]).sum(axis=1)  # [s, t]
hol_rows = []
for t in np.where(is_hol[:T])[0]:
    cands = [t + 7 * k for k in range(-4, 5) if k != 0 and 0 <= t + 7 * k < T and not is_hol[t + 7 * k]]
    for si, s in enumerate(stores):
        exp = tot[si, cands].mean()
        hol_rows.append({"date": dates[t], "weekday": WD[wd[t]], "name": hol_name.get(dates[t], ""), "store": s, "actual": tot[si, t], "expected": exp, "ratio": tot[si, t] / exp if exp > 0 else np.nan, "weekend": wd[t] >= 5})
hol_df = pd.DataFrame(hol_rows)
hol_factor = {}
for si, s in enumerate(stores):
    g = hol_df[hol_df.store == s]
    for wk_end in (False, True):
        gg = g[g.weekend == wk_end]
        f_all = g.actual.sum() / g.expected.sum()
        hol_factor[(s, wk_end)] = gg.actual.sum() / gg.expected.sum() if len(gg) >= 3 else f_all
hol_tbl = pd.DataFrame([{"store": s, "평일공휴일 계수": round(hol_factor[(s, False)], 3), "주말공휴일 계수": round(hol_factor[(s, True)], 3),
                         "표본(평일/주말)": f"{int((hol_df[(hol_df.store == s) & (~hol_df.weekend)].shape[0]))}/{int((hol_df[(hol_df.store == s) & (hol_df.weekend)].shape[0]))}"} for s in stores])


def hfac(si, t):
    return hol_factor[(stores[si], wd[t] >= 5)] if is_hol[t] else 1.0


# ---- 기준값: 같은 요일 최근 4회 평균 (공휴일·미취급 제외, 최대 6주), 모든 t에 대해 (t-7k 만 사용하므로 기준일 무관)
BASE = np.full((3, len(menu_ids), N), np.nan); BASE_SRC = {}
for si in range(3):
    for mi in range(len(menu_ids)):
        x = X[si, mi]; a = A[si, mi]
        for t in range(28, N):
            picks = []
            for k in range(1, 7):
                q = t - 7 * k
                if q < 0 or q >= T or is_hol[q] or not a[q]:
                    continue
                picks.append(q)
                if len(picks) == 4:
                    break
            if picks:
                BASE[si, mi, t] = x[picks].mean()
                if t >= T:
                    BASE_SRC[(si, mi, t)] = picks
FC = BASE * np.array([[[hfac(si, t) for t in range(N)] for _ in menu_ids] for si in range(3)]) * A

# ---- 백테스트 (3/1~9/30 목표일, 기준일 i → i+1..i+7) → 식자재 커버합계 잔차 RMSE
B = np.zeros((len(menu_ids), len(ing_ids)))
for r in bom.itertuples():
    B[menu_ids.index(r.menu_id), ing_ids.index(r.ingredient_id)] = r.qty_per_menu
H = 7
origins = [i for i in range(T) if dates[i] >= pd.Timestamp("2026-02-28") and i + H < T]
Fm = np.zeros((3, len(menu_ids), len(origins), H)); Ym = np.zeros_like(Fm); Mk = np.zeros_like(Fm, dtype=bool)
for oi, i in enumerate(origins):
    hist_ok = A[:, :, max(0, i - 27):i + 1].sum(axis=2) >= 28
    for h in range(H):
        j = i + 1 + h
        Fm[:, :, oi, h] = np.nan_to_num(FC[:, :, j]); Ym[:, :, oi, h] = np.nan_to_num(X[:, :, j])
        Mk[:, :, oi, h] = A[:, :, j] & hist_ok
Fi = np.einsum("smoh,mi->sioh", Fm * Mk, B); Yi = np.einsum("smoh,mi->sioh", Ym * Mk, B)
Fc = Fi.cumsum(axis=3); Yc = Yi.cumsum(axis=3); R = Fc - Yc           # [s, i, o, L-1]
valid_o = Mk.any(axis=1).all(axis=2)                                 # [s, o]: 그 기준일에 평가 가능
rmse = np.zeros((3, len(ing_ids), H)); bias = np.zeros_like(rmse); mean_y = np.zeros_like(rmse); wape_ing = np.zeros_like(rmse)
for si in range(3):
    ok = valid_o[si]
    rmse[si] = np.sqrt((R[si][:, ok, :] ** 2).mean(axis=1)); bias[si] = R[si][:, ok, :].mean(axis=1)
    mean_y[si] = Yc[si][:, ok, :].mean(axis=1); wape_ing[si] = np.abs(R[si][:, ok, :]).sum(axis=1) / np.maximum(Yc[si][:, ok, :].sum(axis=1), 1e-9) * 100
# 메뉴 단위 참고 지표
okm = Mk & (Fm >= 0)
menu_wape = np.abs(Fm[okm] - Ym[okm]).sum() / Ym[okm].sum() * 100
ing_wape3 = np.abs(R[:, :, :, 2][np.broadcast_to(valid_o[:, None, :], R[:, :, :, 2].shape)]).sum() / Yc[:, :, :, 2][np.broadcast_to(valid_o[:, None, :], R[:, :, :, 2].shape)].sum() * 100

# ---- 급변 플래그 (식자재 소요량 2주/8주, 기준일 9/30)
req_hist = np.einsum("smt,mi->sit", np.nan_to_num(X[:, :, :T]) * A[:, :, :T], B)
r2 = req_hist[:, :, T - 14:T].mean(axis=2); r8 = req_hist[:, :, T - 56:T].mean(axis=2)
shift_ratio = np.where(r8 > 0, r2 / np.where(r8 > 0, r8, 1), np.nan)
shift_flag = (shift_ratio >= 1.3) | (shift_ratio <= 0.77)

# ================================================================= 출력 1. 메뉴 예측표 (long, 근거 포함)
rows = []
for si, s in enumerate(stores):
    for mi, m in enumerate(menu_ids):
        for t in range(T, N):
            picks = BASE_SRC.get((si, mi, t), [])
            rows.append({"store_id": s, "menu_id": m, "menu_name": menus.menu_name[mi], "date": dates[t].date(), "weekday": WD[wd[t]],
                         "is_holiday": int(is_hol[t]), "holiday_name": hol_name.get(dates[t], "") if is_hol[t] else "",
                         "available": int(A[si, mi, t]),
                         "base_dates": ";".join(str(dates[q].date()) for q in picks), "base_values": ";".join(f"{X[si, mi, q]:g}" for q in picks),
                         "base_mean": round(float(BASE[si, mi, t]), 2) if not np.isnan(BASE[si, mi, t]) else np.nan,
                         "holiday_factor": round(hfac(si, t), 3), "forecast_qty": round(float(np.nan_to_num(FC[si, mi, t])), 2)})
menu_fc = pd.DataFrame(rows)
menu_fc.to_csv(OUT / "forecast_menu_daily.csv", index=False, encoding="utf-8-sig")

# ================================================================= 출력 2. 식자재 일별 소요량
req_fc = np.einsum("smt,mi->sit", np.nan_to_num(FC[:, :, T:]), B)  # [s, i, h]
rows = []
for si, s in enumerate(stores):
    for ii, iid in enumerate(ing_ids):
        for h in range(HORIZON):
            rows.append({"store_id": s, "ingredient_id": iid, "ingredient_name": ing.ingredient_name[ii], "use_unit": ing.use_unit[ii],
                         "date": dates[T + h].date(), "weekday": WD[wd[T + h]], "is_holiday": int(is_hol[T + h]), "requirement_qty": round(float(req_fc[si, ii, h]), 1)})
ing_fc = pd.DataFrame(rows); ing_fc.to_csv(OUT / "forecast_ingredient_daily.csv", index=False, encoding="utf-8-sig")

# ================================================================= 출력 3. 식자재 커버구간 합계 + σ + 안전재고 (+ 참고: 9/30 재고, 10/1 입고예정)
closing = inv[inv.date == ASOF].set_index(["store_id", "ingredient_id"]).closing_qty
rc_lines = set(rc.po_line_id)
open_po = po[~po.po_line_id.isin(rc_lines)].merge(ing[["ingredient_id", "use_qty_per_order_unit"]], on="ingredient_id")
open_po["use_qty"] = open_po.order_qty * open_po.use_qty_per_order_unit
inbound = open_po.groupby(["store_id", "ingredient_id"]).use_qty.sum()
rows = []
for si, s in enumerate(stores):
    for ii, iid in enumerate(ing_ids):
        r = {"store_id": s, "ingredient_id": iid, "ingredient_name": ing.ingredient_name[ii], "storage": ing.storage[ii], "use_unit": ing.use_unit[ii],
             "shelf_life_days": ing.shelf_life_days[ii]}
        for h in range(7):
            r[f"d{h + 1}_{dates[T + h].strftime('%m/%d')}({WD[wd[T + h]]}{'·휴' if is_hol[T + h] else ''})"] = round(float(req_fc[si, ii, h]), 1)
        for L in (1, 3, 7):
            r[f"sum_{L}d"] = round(float(req_fc[si, ii, :L].sum()), 1)
            r[f"sigma_{L}d"] = round(float(rmse[si, ii, L - 1]), 1)
        r["cv_3d_%"] = round(float(rmse[si, ii, 2] / mean_y[si, ii, 2] * 100), 0) if mean_y[si, ii, 2] > 0 else np.nan
        r["bias_3d_%"] = round(float(bias[si, ii, 2] / mean_y[si, ii, 2] * 100), 1) if mean_y[si, ii, 2] > 0 else np.nan
        r["shift_ratio_2w_8w"] = round(float(shift_ratio[si, ii]), 2) if not np.isnan(shift_ratio[si, ii]) else np.nan
        r["shift_flag"] = int(bool(shift_flag[si, ii]))
        mult = SHIFT_MULT if shift_flag[si, ii] else 1.0
        r["sigma_3d_adj"] = round(float(rmse[si, ii, 2] * mult), 1)
        r["safety_95_3d"] = round(float(Z95 * rmse[si, ii, 2] * mult), 1)
        r["need_3d_with_safety"] = round(r["sum_3d"] + r["safety_95_3d"], 1)
        r["closing_0930"] = float(closing.get((s, iid), 0)); r["inbound_1001"] = float(inbound.get((s, iid), 0))
        rows.append(r)
win = pd.DataFrame(rows); win.to_csv(OUT / "forecast_ingredient_window.csv", index=False, encoding="utf-8-sig")
hol_df.round(2).to_csv(OUT / "holiday_factor_detail.csv", index=False, encoding="utf-8-sig")

# ================================================================= 요약 출력
print("=== 공휴일 계수 (매장별, 같은 요일 ±4주 비공휴일 평균 대비) ===")
print(hol_tbl.to_string(index=False))
print("\n=== 백테스트 (이 방법, 3/1~9/30): 메뉴 1~7일 WAPE %.1f%% · 식자재 1~3일 합계 WAPE %.1f%%" % (menu_wape, ing_wape3))
print("\n=== 메뉴 예측 (개/일) — 10/1(목)~10/7(수), 매장별 ===")
for s in stores:
    p = menu_fc[(menu_fc.store_id == s) & (menu_fc.date <= pd.Timestamp("2026-10-07").date())].pivot_table(index=["menu_id", "menu_name"], columns="date", values="forecast_qty")
    p.columns = [f"{c.strftime('%m/%d')}{WD[c.weekday()]}{'휴' if pd.Timestamp(c) in FUTURE_HOL else ''}" for c in p.columns]
    print(f"\n[{s}] 7일 합계 {p.sum().sum():,.0f}개"); print(p.round(1).to_string())
print("\n=== 식자재 소요량 예측 — S01, 10/1~10/3 합계 + σ + 안전재고(95%) ===")
cols = ["ingredient_id", "ingredient_name", "use_unit", "sum_1d", "sum_3d", "sum_7d", "sigma_3d", "cv_3d_%", "shift_ratio_2w_8w", "shift_flag", "safety_95_3d", "need_3d_with_safety", "closing_0930", "inbound_1001"]
print(win[win.store_id == "S01"][cols].to_string(index=False))
print("\n=== 급변 플래그가 선 조합 ===")
print(win[win.shift_flag == 1][["store_id", "ingredient_id", "ingredient_name", "shift_ratio_2w_8w", "sum_3d", "sigma_3d", "sigma_3d_adj"]].to_string(index=False))
print("\n=== 식자재 단위 변동계수 cv_3d 분포 (매장별 중앙값) ===")
print(win.groupby("store_id")["cv_3d_%"].median().round(0).to_string())
print("\n저장:", sorted(p.name for p in OUT.glob("*.csv")))
