"""메뉴 수요 예측 방법 비교 백테스트 (읽기 전용). 사용: python -I -X utf8 backtest_forecast.py <csv 폴더>
방법: MA7, MA28, SWD4(같은 요일 4주 평균), SWD4xTrend, EWMA×요일지수. 1~7일 앞. 평가 3/1~9/30.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

pd.set_option("display.width", 220); pd.set_option("display.max_columns", 30)
D = Path(sys.argv[1])
rd = lambda n: pd.read_csv(next(D.glob(f"{n}_*.csv")), encoding="utf-8-sig")
menus = rd("02"); avail = rd("15"); cal = rd("07"); bom = rd("04"); ing = rd("03")
sales = rd("09"); sales["date"] = pd.to_datetime(sales["date"]); cal["date"] = pd.to_datetime(cal["date"])
dates = pd.DatetimeIndex(cal.date); T = len(dates); didx = {d: i for i, d in enumerate(dates)}
is_hol = cal.is_holiday.values.astype(bool)
wd = np.array([d.weekday() for d in dates])  # 0=월
stores = ["S01", "S02", "S03"]; menu_ids = list(menus.menu_id)

# 일별 수요 행렬 X[store, menu, t]; 취급 마스크 A (취급표 ∧ 첫 판매일 이후)
daily = sales.groupby(["store_id", "menu_id", "date"]).demand_qty.sum()
X = np.zeros((3, len(menu_ids), T)); A = np.zeros_like(X, dtype=bool)
for (s, m, d), v in daily.items():
    X[stores.index(s), menu_ids.index(m), didx[d]] = v
for r in avail.itertuples():
    if r.status == "취급" and isinstance(r.start_date, str):
        si, mi = stores.index(r.store_id), menu_ids.index(r.menu_id)
        A[si, mi, didx[pd.Timestamp(r.start_date)]:didx[pd.Timestamp(r.end_date)] + 1] = True
for si in range(3):
    for mi in range(len(menu_ids)):
        nz = np.where(X[si, mi] > 0)[0]
        if len(nz):
            A[si, mi, :nz[0]] = False  # 첫 판매일 전은 '취급 중 주문 없음' → 제외
        else:
            A[si, mi, :] = False

H = 7
origins = [i for i in range(T) if dates[i] >= pd.Timestamp("2026-02-28") and i + H < T]


def forecast_all(method):
    """F[store, menu, origin_idx, h] (h=0..6 → t+1..t+7). 기준일 i까지의 X만 사용."""
    F = np.full((3, len(menu_ids), len(origins), H), np.nan)
    for si in range(3):
        for mi in range(len(menu_ids)):
            x = X[si, mi]; a = A[si, mi]
            for oi, i in enumerate(origins):
                if not a[i] or a[max(0, i - 27):i + 1].sum() < 28:  # 28일 이력 필요
                    continue
                hist = x[:i + 1]
                if method == "MA7":
                    F[si, mi, oi, :] = hist[-7:].mean()
                elif method == "MA28":
                    F[si, mi, oi, :] = hist[-28:].mean()
                elif method in ("SWD4", "SWD4xT", "SWD4xT_noHol"):
                    tr = 1.0
                    if method != "SWD4":
                        m2, m8 = hist[-14:].mean(), hist[-56:].mean() if i >= 55 else hist[-28:].mean()
                        tr = float(np.clip(m2 / m8, 0.7, 1.3)) if m8 > 0 else 1.0
                    for h in range(H):
                        j = i + 1 + h
                        idxs = [j - 7 * k for k in range(1, 5) if j - 7 * k >= 0 and j - 7 * k <= i]
                        if method == "SWD4xT_noHol":
                            idxs2 = [q for q in idxs if not is_hol[q]]
                            idxs = idxs2 if len(idxs2) >= 2 else idxs
                        F[si, mi, oi, h] = x[idxs].mean() * tr if idxs else np.nan
                elif method == "EWMAxWD":
                    w = hist[-56:]; wdw = wd[i + 1 - len(w):i + 1]
                    mean_all = w.mean()
                    if mean_all <= 0:
                        F[si, mi, oi, :] = 0; continue
                    idx = np.array([w[wdw == k].mean() / mean_all if (wdw == k).any() else 1.0 for k in range(7)])
                    des = w / np.where(idx[wdw] > 0, idx[wdw], 1.0)
                    lvl = des[0]
                    for v in des[1:]:
                        lvl = 0.2 * v + 0.8 * lvl
                    for h in range(H):
                        F[si, mi, oi, h] = lvl * idx[wd[i + 1 + h]]
    return F


# 실제값 Y[store, menu, origin, h], 평가 마스크(취급일만)
Y = np.full((3, len(menu_ids), len(origins), H), np.nan); M = np.zeros_like(Y, dtype=bool); HOL = np.zeros_like(Y, dtype=bool)
for oi, i in enumerate(origins):
    for h in range(H):
        Y[:, :, oi, h] = X[:, :, i + 1 + h]; M[:, :, oi, h] = A[:, :, i + 1 + h]; HOL[:, :, oi, h] = is_hol[i + 1 + h]

methods = ["MA7", "MA28", "SWD4", "SWD4xT", "SWD4xT_noHol", "EWMAxWD"]
res = {m: forecast_all(m) for m in methods}


def wape(F, mask):
    ok = mask & ~np.isnan(F) & ~np.isnan(Y)
    return np.abs(F[ok] - Y[ok]).sum() / Y[ok].sum() * 100, (F[ok] - Y[ok]).sum() / Y[ok].sum() * 100


print("=== 메뉴 단위 WAPE % (Σ|오차|/Σ실제), 1~7일 앞 전체, 평가 2026-03-01~09-30 ===")
rows = []
for m in methods:
    F = res[m]
    r = {"방법": m}
    r["전체"], r["편향"] = wape(F, M)
    for h in (0, 2, 6):
        r[f"h={h + 1}"] = wape(F, M & (np.arange(H) == h)[None, None, None, :])[0]
    for si, s in enumerate(stores):
        mk = np.zeros_like(M); mk[si] = M[si]; r[s] = wape(F, mk)[0]
    r["공휴일만"] = wape(F, M & HOL)[0]; r["평일만"] = wape(F, M & ~HOL)[0]
    rows.append(r)
print(pd.DataFrame(rows).round(1).to_string(index=False))

# 식자재 단위: BOM 으로 집계 (소요량), 1~3일 앞 합계 (전형적 커버 구간)
B = np.zeros((len(menu_ids), len(ing)))
for r in bom.itertuples():
    B[menu_ids.index(r.menu_id), list(ing.ingredient_id).index(r.ingredient_id)] = r.qty_per_menu
Yi = np.einsum("smoh,mi->sioh", np.nan_to_num(Y * M), B)
print("\n=== 식자재 단위 WAPE % (예측 × BOM 집계, 1~3일 합계 소요량, 매장×식자재별 합산) ===")
rows = []
for m in methods:
    F = res[m]; Fi = np.einsum("smoh,mi->sioh", np.nan_to_num(F * M), B)
    valid = (M.any(axis=1))  # origin×h 에 평가 대상이 있는지 (store, origin, h)
    f3 = Fi[:, :, :, :3].sum(axis=3); y3 = Yi[:, :, :, :3].sum(axis=3); v3 = valid[:, :, :3].all(axis=2)
    r = {"방법": m}
    ok = np.broadcast_to(v3[:, None, :], f3.shape) & (y3 > 0)
    r["전체"] = np.abs(f3[ok] - y3[ok]).sum() / y3[ok].sum() * 100
    for grp in ["냉장", "냉동", "상온"]:
        gi = np.where(ing.storage.values == grp)[0]
        okg = ok[:, gi, :]
        r[grp] = np.abs(f3[:, gi, :][okg] - y3[:, gi, :][okg]).sum() / y3[:, gi, :][okg].sum() * 100
    for si, s in enumerate(stores):
        r[s] = np.abs(f3[si][ok[si]] - y3[si][ok[si]]).sum() / y3[si][ok[si]].sum() * 100
    rows.append(r)
print(pd.DataFrame(rows).round(1).to_string(index=False))

# 변동성 수치: 최적 방법의 1일 앞 오차의 상대 표준편차 (매장×메뉴), 상위/하위
best = "SWD4xT_noHol"
F = res[best]; e = (F[:, :, :, 0] - Y[:, :, :, 0]); ok = M[:, :, :, 0] & ~np.isnan(F[:, :, :, 0])
vol = []
for si, s in enumerate(stores):
    for mi, mid in enumerate(menu_ids):
        k = ok[si, mi]
        if k.sum() < 30: continue
        mean_y = Y[si, mi, k, 0].mean()
        vol.append({"store": s, "menu": f"{mid} {menus.menu_name[mi]}", "일평균": round(mean_y, 1), "오차표준편차": round(e[si, mi, k].std(), 2), "CV%": round(e[si, mi, k].std() / mean_y * 100, 0) if mean_y > 0 else np.nan, "WAPE%": round(np.abs(e[si, mi, k]).sum() / Y[si, mi, k, 0].sum() * 100, 0)})
vol = pd.DataFrame(vol)
print(f"\n=== 변동성 수치 ({best}, 1일 앞 오차 기준) — 안전재고 σ 후보. CV 높은 순 ===")
print(vol.sort_values("CV%", ascending=False).head(12).to_string(index=False))
print("... CV 낮은 순"); print(vol.sort_values("CV%").head(6).to_string(index=False))
print("\n=== 급변 구간 민감도: 최근 2주/8주 비율이 1.3 이상이거나 0.77 이하인 기준일만 (SWD4 vs SWD4xT) ===")
rat = np.full((3, len(menu_ids), len(origins)), np.nan)
for si in range(3):
    for mi in range(len(menu_ids)):
        for oi, i in enumerate(origins):
            if i >= 55 and A[si, mi, i]:
                m8 = X[si, mi, i - 55:i + 1].mean(); rat[si, mi, oi] = X[si, mi, i - 13:i + 1].mean() / m8 if m8 > 0 else np.nan
shift = ((rat >= 1.3) | (rat <= 0.77))[:, :, :, None] & M
for m in ["MA7", "SWD4", "SWD4xT", "EWMAxWD"]:
    print(f"  {m:8s} 급변 기준일 WAPE {wape(res[m], shift)[0]:.1f}%  편향 {wape(res[m], shift)[1]:+.1f}%   | 평시 WAPE {wape(res[m], M & ~shift)[0]:.1f}%")
