#!/usr/bin/env bash
# 발주안 평가 엔진: data/ 의 CSV 로 추천안·발주없음(+옵션 발주안)을 평가
cd "$(dirname "$0")"
export PYTHONUTF8=1
python run_evaluate.py --data data --out eval_out --scale 1.3 "$@"
echo "결과: $(pwd)/eval_out/compare.csv"
