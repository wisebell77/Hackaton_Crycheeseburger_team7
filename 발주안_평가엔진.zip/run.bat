@echo off
rem Order-plan evaluation engine: evaluates "no order" vs "engine recommendation" (+ x1.3) using CSVs in data\
set PYTHONUTF8=1
cd /d "%~dp0"
python run_evaluate.py --data data --out eval_out --scale 1.3 %*
echo.
echo Results: %~dp0eval_out\compare.csv  (plan comparison), eval_out\^<plan^>\lines.csv (store x ingredient detail)
pause
