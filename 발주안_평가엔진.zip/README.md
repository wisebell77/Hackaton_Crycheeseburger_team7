# 발주안 평가 엔진 (계획 (2)) — CSV 넣고 바로 실행

이 묶음은 **발주안 평가 엔진만** 들어 있다. 압축을 푼 폴더의 `data/`에 제공 CSV 17개를 넣고 실행하면
① 엔진이 만든 **추천 발주안(예측)**과 ② **발주 없음**을 평가해 비교하고, ③ 내가 쓴 발주안 CSV도 같은 잣대로 평가한다.

## 1. 실행

```
1) data/ 폴더에 01_stores.csv ~ 17_stockouts.csv 를 넣는다 (하위 폴더 하나 안에 있어도, zip 이어도 됨)
2) pip install -r requirements.txt        (pandas, numpy)
3) run.bat 더블클릭   또는   python run_evaluate.py
```

결과는 `eval_out/` 에 생긴다. 첫 실행은 데이터 읽기 포함 10초 안팎.

자주 쓰는 옵션:

```bash
python run_evaluate.py --scale 1.3 --scale 0.7          # 추천안 ×1.3(안전 추구), ×0.7(아끼기) 안을 추가 비교
python run_evaluate.py --plan my_plan.csv               # 내 발주안 평가 (plan_template.csv 를 복사해 수정)
python run_evaluate.py --plan a.csv --plan b.csv --no-default   # 내 발주안들만 비교
python run_evaluate.py --asof 2026-09-23                # 기준일 바꾸기 (과거 날짜로 두고 결과 확인 가능)
python run_evaluate.py --service-level 0.99             # 추천안의 서비스 레벨
python run_evaluate.py --window horizon                 # 평가 창을 '기간 전체(14일, 추가 발주 없음)'로
python run_evaluate.py --data "C:/어딘가/data"           # 다른 위치의 CSV 폴더
```
Windows 콘솔 한글이 깨지면 `set PYTHONUTF8=1` 후 실행 (run.bat 은 자동 설정).

## 2. 발주안 CSV 형식 (`plan_template.csv`)

| 열 | 뜻 | 비고 |
|---|---|---|
| store_id | 매장 | S01~S03 |
| ingredient_id | 식자재 | I001~I022 |
| order_qty | 발주 수량 (발주단위: 박스·팩·EA 등) | 정수 |
| order_date | 발주일 (선택) | 비우면 판단 시각(기준일 다음 날 09:00) 이후 첫 발주 가능일 |
| arrival_date | 도착일 (선택) | 비우면 공급사 달력(발주 요일·마감·리드타임·입고 요일)으로 계산 |
| order_type | 정기 / 긴급 (선택) | 긴급은 요일 무관 발주 다음 날 도착 |

## 3. 결과 읽는 법

`eval_out/compare.csv` — 발주안별 한 줄:

| 열 | 뜻 |
|---|---|
| 발주 금액 | 발주 수량 × 발주일 단가 (지출, 손실 아님) |
| 기대 품절 손실매출 | 평가 창 안에서 재료가 모자라 못 판 메뉴 매출의 시나리오 평균 |
| 기대 폐기 비용 | 기간 안에 사용기한이 지나 버리는 양 × 단가의 평균 (기존 재고 + 이번 발주 로트) |
| 기대 총손실 / p90 총손실 | 둘의 합의 평균 / 나쁜 쪽 10% 경계 |
| 기대 품절 품목 수(창 내) | 시나리오당 평균 몇 개 매장×식자재가 모자라는가 |
| 기대 경로 … | 변동성 없이 점 예측 그대로 갔을 때 |

`eval_out/<발주안>/lines.csv` — 매장×식자재 한 줄: 평가 창, 발주량, 현재고, 입고예정, 창 내 소요, 기대 경로 품절·폐기·기말 커버일수,
시나리오 분포(p_stockout_window, shortage_window_p90, lost_revenue_mean, waste_p90, loss_p90 …).
`daily.csv` 는 기대 경로의 일별 재고 곡선(+p90 부족, p10 재고), `scenarios.csv` 는 시나리오별 총손실, `plan_normalized.csv` 는 도착일·단가를 붙인 발주안.

## 4. 어떻게 계산하나 (요약)

- **수요 예측**: 메뉴별 같은 요일 최근 4회 평균(공휴일·미취급·첫 판매 전 제외) × 매장별 공휴일 계수 → BOM 으로 식자재 소요량.
  실데이터 3~9월 백테스트에서 고른 식 (식자재 1~3일 소요 WAPE 10.8%).
- **평가 창**: 내일부터 '그 다음 발주분 도착 전날'까지. 그 뒤 품절은 다음 발주 결정의 몫. 폐기는 14일 전체(이후 추가 발주 없음 가정).
- **변동성**: 같은 예측식을 과거에 매일 적용했을 때의 식자재별 실제÷예측 비율을 14일 블록으로 잘라 시나리오(실데이터 232개)로 쓴다. 분포 가정 없음.
- **재고 전개**: 기준일 로트 잔량 + 미입고 PO + 발주안 로트를 FEFO 로 소진. 07시 입고 → 기한 지난 로트 폐기 → 소진 → 기말.
- **손실 환산**: 품절 = Σ 메뉴가격 × 예측 판매 × (그 메뉴 재료 중 가장 모자란 재료의 부족 비율). 폐기 = 수량 × 기준일 단가.

코드: `src/engine/evaluate.py` (평가), `src/engine/forecast.py`·`requirement.py` (예측·σ), `src/engine/projection.py`·`order.py` (재고 전개·추천안). 데이터 로더는 `src/loader.py`.
