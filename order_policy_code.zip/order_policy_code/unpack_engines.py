"""저장소의 두 엔진 ZIP을 engines/ 하위에 푼다. 원본 ZIP은 유지한다."""
from pathlib import Path
import zipfile


def main():
    root=Path(__file__).resolve().parent
    for name in ("발주안_평가엔진", "forecast_engine_code"):
        source=root/(name+".zip")
        target=root/"engines"/name
        with zipfile.ZipFile(source) as z:
            for info in z.infolist():
                path=(target/info.filename).resolve()
                if not path.is_relative_to(target.resolve()) or ((info.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError("안전하지 않은 ZIP 경로/링크")
            target.mkdir(parents=True,exist_ok=True)
            z.extractall(target)
        print(target)


if __name__=="__main__":
    main()
