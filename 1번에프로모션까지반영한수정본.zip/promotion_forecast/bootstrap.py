"""Reuse the checked-in engine ZIP without overwriting existing source files."""
from pathlib import Path
import stat
import sys
import zipfile


def load_engine(root, explicit=None):
    root = Path(root).resolve()
    engine = Path(explicit).resolve() if explicit else root / "engines" / "forecast_engine_code"
    if not (engine / "src" / "engine" / "forecast.py").is_file():
        if explicit or engine.exists():
            raise ValueError(f"유효한 예측 엔진 폴더가 아닙니다: {engine}")
        with zipfile.ZipFile(root / "forecast_engine_code.zip") as z:
            if sum(i.file_size for i in z.infolist()) > 50_000_000:
                raise ValueError("엔진 ZIP 크기 초과")
            for info in z.infolist():
                if not (engine / info.filename).resolve().is_relative_to(engine.resolve()) or stat.S_ISLNK(info.external_attr >> 16):
                    raise ValueError("엔진 ZIP의 잘못된 경로/심볼릭 링크")
            z.extractall(engine)
    if "src" in sys.modules:
        loaded = Path(sys.modules["src"].__file__).resolve().parent
        if loaded != engine / "src":
            raise ValueError("다른 src 엔진이 이미 로드됐습니다. 새 프로세스에서 실행하세요.")
    sys.path.insert(0, str(engine))
    return engine
